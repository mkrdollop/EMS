module.exports = {

    HOST: "localhost",
    USER: "root",
    PASSWORD: "",
    DB: "ems_db",
    PORT: 3306
}
